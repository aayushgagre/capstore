package com.cg.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.bean.Product;

public interface PlacedOrderDAO extends JpaRepository<Product, Integer> {

}
