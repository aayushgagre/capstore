package com.cg.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Product;
import com.cg.daos.PlacedOrderDAO;

@Service
@Transactional
public class OrderServicesImpl implements OrderServices {

	@Autowired
	PlacedOrderDAO dao;

	public Product findById(Integer[] pid) {

		Optional<Product> product = dao.findById(pid[0]);
		return product.get();
	}

	public boolean updateProducts(Product product, Integer[] cart_quantity) {

		int quantity=product.getQuantity();

		if (cart_quantity[0] >= quantity) {
			int new_quantity = quantity - cart_quantity[0];
			product.setQuantity(new_quantity);
			int sold_quantity = product.getSoldQuantities();
			int new_sold_quantity = sold_quantity + cart_quantity[0];
			product.setSoldQuantities(new_sold_quantity);
			dao.save(product);
			return true;
		} else
			return false;
	}

}
