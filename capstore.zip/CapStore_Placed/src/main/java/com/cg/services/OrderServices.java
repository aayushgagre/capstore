package com.cg.services;

import com.cg.bean.Product;

public interface OrderServices {
	
	public Product findById(Integer[] pid);
	
	public boolean updateProducts(Product p, Integer[] quantity);
}
