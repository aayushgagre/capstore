package com.cg.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.services.OrderServices;

@RequestMapping(value = "/")
public class PlacedController {

	@Autowired
	OrderServices service;

	@RequestMapping(value = "/placingorder/{modeof}")
	public boolean placeOrder(@RequestBody Cart cart) {
		List<Integer[]> products = cart.getProducts();

		for (Integer[] p : products) {
			Integer[] pid = products.get(p[0]);
			Integer[] quantity = products.get(p[1]);
			Product product = service.findById(pid);
			service.updateProducts(product, quantity);

		}

		return true;

	}

}
